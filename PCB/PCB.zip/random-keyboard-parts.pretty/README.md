# random-keyboard-parts.pretty
KiCad Footprint and Schematic modules for random components that don't fit in their own repo
